Demo images
